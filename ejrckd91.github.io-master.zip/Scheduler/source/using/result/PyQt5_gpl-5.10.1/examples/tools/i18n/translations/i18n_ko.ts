<!DOCTYPE TS><TS>
<context>
    <name>MainWindow</name>
    <message>
        <source>&amp;File</source>
        <translation>파일&amp;F</translation>
    </message>
    <message>
        <source>E&amp;xit</source>
        <translation>종료&amp;X</translation>
    </message>
    <message>
        <source>First</source>
        <translation>첫번째</translation>
    </message>
    <message>
        <source>Internationalization Example</source>
        <translation>국제화 예제</translation>
    </message>
    <message>
        <source>Isometric</source>
        <translation>등측도</translation>
    </message>
    <message>
        <source>Language: %1</source>
        <translation>언어 : %1</translation>
    </message>
    <message>
        <source>English</source>
        <translation>한국어</translation>
    </message>
    <message>
        <source>Oblique</source>
        <translation>빗각</translation>
    </message>
    <message>
        <source>Perspective</source>
        <translation>원근화법</translation>
    </message>
    <message>
        <source>Second</source>
        <translation>두번째</translation>
    </message>
    <message>
        <source>Third</source>
        <translation>세번째</translation>
    </message>
    <message>
        <source>View</source>
        <translation>보기</translation>
    </message>
    <message>
        <source>LTR</source>
        <translation>LTR</translation>
    </message>
</context>
</TS>
